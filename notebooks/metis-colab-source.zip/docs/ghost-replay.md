# Ghost/QAC offline replay contract

`metis-replay CHECKPOINT INPUT.jsonl OUTPUT.jsonl` accepts one JSON object per line. Each row must contain a complete fixed-schema Metis state, either at the row root or under `state`. Enum values are their declared uppercase names. `historical_choice` is optional and is compared case-insensitively with `CONTINUE`, `ESCALATE`, `DECOMPOSE`, or `ABSTAIN`.

```json
{
  "id": "ghost-work-turn-123",
  "state": {
    "phase": "EXECUTE",
    "current_resource_tier": "MEDIUM",
    "phase_attempts": 2,
    "consecutive_phase_attempts": 1,
    "failed_attempts": 1,
    "reopen_count": 0,
    "progress": "UNKNOWN",
    "progress_evidence": "NONE",
    "artifact_valid": false,
    "artifact_accepted": false,
    "open_unknowns": 2,
    "active_contradictions": 0,
    "has_leading_hypothesis": false,
    "has_active_frame": false,
    "uncertainty": 0.7,
    "novelty": 0.4,
    "budget_pressure": 0.2,
    "resource_scarcity": 0.1
  },
  "historical_choice": "ESCALATE"
}
```

The example demonstrates syntax only; it is not an observed Ghost decision. Keep real records separate from training datasets. Never fill unavailable fields with `0` or `false` as a convenience: those values mean evidence was observed. In particular, use `progress: UNKNOWN` only when progress is missing, and preserve its evidence strength as `NONE`.

## Current Ghost source coverage

The adjacent Ghost worktree has a structured `QACRequest` with direction, uncertainty, novelty, expected gain, failed attempts, evidence text, attempted actions, and unresolved text. Its `WorkItem` carries owner resource and handoff count, and its QAC configuration carries resource capability, cost, scarcity, and budgets. Those values could seed an export adapter.

The existing Ghost trace writer persists only time, source, kind, message, session ID, turn ID, and raw event bytes. The QAC event currently stores a display string such as an action, resource transition, score, and threshold. It does not preserve the full request, resource/budget snapshot, phase attempts, progress/evidence classification, artifact status, unknown count, contradictions, active hypothesis, or active frame. The inspected worktree contained no QAC JSONL export. Therefore its current trace cannot be losslessly converted to a complete Metis state.

To complete M6, add or provide a decision-time research export containing the full Metis fields plus the historical action. Export the actual observed values and an explicit missingness policy; do not train on that export. Then replay it with `metis-replay`, inspect agreement and disagreements, and keep the exported records outside training splits.
