"""Training and evaluation utilities."""

